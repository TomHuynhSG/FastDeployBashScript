<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/accounts/admin.yaml',
    'modified' => 1463959257,
    'data' => [
        'email' => 'johnpham064@gmail.com',
        'fullname' => 'john',
        'title' => 'Mr',
        'state' => 'enabled',
        'access' => [
            'admin' => [
                'login' => 'true',
                'super' => 'true'
            ],
            'site' => [
                'login' => 'true'
            ]
        ],
        'hashed_password' => '$2y$10$/lPYvSQJmed8nWgmzQDuGOeDyhi3u6Wo0dg1gj5Y2mJ74kuvWZ/gm',
        'language' => 'en'
    ]
];
