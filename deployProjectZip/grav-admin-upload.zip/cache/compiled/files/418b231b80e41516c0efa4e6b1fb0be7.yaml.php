<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/plugins/taxonomylist/taxonomylist.yaml',
    'modified' => 1463958834,
    'data' => [
        'enabled' => true,
        'route' => '/blog'
    ]
];
