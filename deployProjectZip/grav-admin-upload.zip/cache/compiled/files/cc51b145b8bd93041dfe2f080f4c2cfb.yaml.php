<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/plugins/form/form.yaml',
    'modified' => 1461712048,
    'data' => [
        'enabled' => true,
        'files' => [
            'multiple' => false,
            'destination' => '@self',
            'accept' => [
                0 => 'image/*'
            ]
        ]
    ]
];
