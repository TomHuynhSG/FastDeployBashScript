<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/themes/antimatter/languages.yaml',
    'modified' => 1461712048,
    'data' => [
        'en' => [
            'TRANSLATION_TEST' => 'Antimatter!'
        ]
    ]
];
