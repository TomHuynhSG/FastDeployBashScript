<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/config/security.yaml',
    'modified' => 1463958676,
    'data' => [
        'salt' => '8Uli3QNcMIK9AE'
    ]
];
