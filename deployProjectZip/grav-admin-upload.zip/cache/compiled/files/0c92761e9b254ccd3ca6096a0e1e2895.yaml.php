<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/accounts/editor.yaml',
    'modified' => 1463959200,
    'data' => [
        'email' => 'johnpham064@gmail.com',
        'fullname' => 'john',
        'title' => 'Mr',
        'state' => 'enabled',
        'access' => [
            'admin' => [
                'login' => true,
                'super' => false,
                'pages' => true,
                'maintenance' => false,
                'plugins' => false,
                'themes' => false
            ],
            'site' => [
                'login' => true
            ]
        ],
        'hashed_password' => '$2y$10$pSumuOL2tIAlGcLMHILYwu/vwc8AWg7Hv.uraJo9c8FUY9vmcR47G',
        'language' => 'en'
    ]
];
