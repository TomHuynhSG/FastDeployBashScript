<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/plugins/admin/languages/lt.yaml',
    'modified' => 1461712048,
    'data' => [
        'PLUGIN_ADMIN' => [
            'MANAGE_PAGES' => 'Tvarkyti puslapius',
            'PAGES' => 'Puslapiai',
            'THEMES' => 'Temos',
            'BACK' => 'Atgal',
            'MOVE' => 'Perkelti',
            'DELETE' => 'Ištrinti',
            'SAVE' => 'Išsaugoti',
            'ERROR' => 'Klaida',
            'CANCEL' => 'Atšaukti',
            'CONTINUE' => 'Tęsti'
        ]
    ]
];
