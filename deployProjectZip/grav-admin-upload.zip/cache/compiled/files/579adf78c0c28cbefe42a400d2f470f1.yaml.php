<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://breadcrumbs/breadcrumbs.yaml',
    'modified' => 1463958842,
    'data' => [
        'enabled' => true,
        'show_all' => true,
        'built_in_css' => true,
        'include_home' => true,
        'icon_home' => '',
        'icon_divider_classes' => 'fa fa-angle-right',
        'link_trailing' => false
    ]
];
