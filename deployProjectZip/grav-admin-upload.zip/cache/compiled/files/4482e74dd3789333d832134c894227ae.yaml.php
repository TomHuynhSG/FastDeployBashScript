<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/system/languages/sv.yaml',
    'modified' => 1461712048,
    'data' => [
        'NICETIME' => [
            'DAY' => 'dag'
        ]
    ]
];
