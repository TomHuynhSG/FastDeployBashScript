<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/plugins/admin/languages/tlh.yaml',
    'modified' => 1461712048,
    'data' => [
        'PLUGIN_ADMIN' => [
            'LOGIN_BTN_FORGOT' => 'lIj',
            'BACK' => 'chap',
            'NORMAL' => 'motlh',
            'YES' => 'HIja\'',
            'NO' => 'Qo\'',
            'DISABLED' => 'Qotlh'
        ]
    ]
];
