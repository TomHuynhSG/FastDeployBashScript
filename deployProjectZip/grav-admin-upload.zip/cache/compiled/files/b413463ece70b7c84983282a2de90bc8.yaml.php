<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/wamp/www/grav-admin/user/config/streams.yaml',
    'modified' => 1463958677,
    'data' => [
        
    ]
];
